const findTutorBtn = document.querySelector('.find-tutor-btn');
const selectSubject = document.querySelector('.select-subject');
const confirmBtn = document.querySelector('#confirm-btn');

findTutorBtn.addEventListener('click', () => {
	selectSubject.style.display = 'block';
});

confirmBtn.addEventListener('click', () => {
	alert('Tutors notified successfully');
});
