from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .forms import SignupForm, SigninForm
from .models import *

def home(request):
     is_authenticated = request.user.is_authenticated
     if request.user.is_authenticated:
         return render(request, 'signin.html', {'is_authenticated': is_authenticated})
     else:
         return render(request, 'signup.html', {'signin_form': SigninForm(), 'signup_form': SignupForm()})



def signin(request):
     if request.method == 'POST':
         form = SigninForm(request.POST)
         if form.is_valid():
             username = form.cleaned_data['username']
             password = form.cleaned_data['password']
             user = authenticate(request, username=username, password=password)
             if user is not None:
                 login(request, user)
                 return redirect('signin')
             else:
                 messages.error(request, 'Wrong username or password')
     return redirect('profile')

def signup(request):
     if request.method == 'POST':
         form = SignupForm(request.POST)
         if form.is_valid():
             username = form.cleaned_data['username']
             email = form.cleaned_data['email']
             password = form.cleaned_data['password']
             user = User.objects.create_user(username=username, password=password)
             user.email = email
             user.save()
             messages.success(request, 'Your account has been created. Login to continue.')
             return redirect('signin')
     return redirect('signin')

def signout(request):
     logout(request)
     if request.user.is_authenticated:
         render(request, 'signin.html', {'signin_form': SigninForm(), 'signup_form': SignupForm()})

     return redirect('signin')


def profile(request):
    is_authenticated = request.user.is_authenticated
    if request.user.is_authenticated:
        return render(request, 'profile.html', {'is_authenticated': is_authenticated})
    else:
        return render(request, 'signin.html', {'signin_form': SigninForm(), 'signup_form': SignupForm()})
   